from rope.base.project import Project
from rope.refactor.rename import Rename

from custom_logger import CustomLogger
from refactoring_base import BaseRefactoring


class RenameRefactoring(BaseRefactoring):

    def apply(self):
        CustomLogger.instance().logger(
            message='Rename refactoring: self.file_to_rename: {} | self.from_position: {} | self.to_rename: {}'.format(
                self.file_to_rename, self.from_position, self.to_rename))
        try:
            project = Project(self.project_folder)
            rename_file = project.get_file(self.file_to_rename)
            changes = Rename(project, rename_file, self.from_position).get_changes(self.to_rename)
            project.do(changes)
        except Exception as err:
            CustomLogger.instance().logger(message='Error during refactoring application. Err: {}'.format(err))
            raise ValueError(err)

    def __init__(self, file_to_rename, from_position, to_rename, project_folder='./'):
        self.file_to_rename = file_to_rename
        self.from_position = from_position
        self.to_rename = to_rename
        self.project_folder = project_folder
