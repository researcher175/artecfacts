from rope.base.project import Project
from rope.refactor import move
from custom_logger import CustomLogger
from refactoring_base import BaseRefactoring


class MoveRefactoring(BaseRefactoring):

    def apply(self):
        CustomLogger.instance().logger(
            message='Move refactoring: self.file_to_refactor: {} | self.from_position: {} | self.to_file: {}'.format(
                self.file_to_refactor, self.from_position, self.to_file))
        try:
            project = Project(self.project_folder)
            from_move_file = self.find_module_in_project(project, self.file_to_refactor)
            to_move_file = self.find_module_in_project(project, self.to_file)
            changes = move.create_move(project, from_move_file, self.from_position).get_changes(
                to_move_file
            )
            project.do(changes)
        except Exception as err:
            CustomLogger.instance().logger(message='Error during refactoring application. Err: {}'.format(err))
            raise ValueError(err)

    def __init__(self, file_to_refactor, from_position, to_file, project_folder='./'):
        self.file_to_refactor = file_to_refactor
        self.from_position = from_position
        self.to_file = to_file
        self.project_folder = project_folder
