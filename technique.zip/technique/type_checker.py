import subprocess

from custom_logger import CustomLogger
from utils import Utils
from shlex import split


class TypeChecker:

    @staticmethod
    def run_pyre(folder):
        result_execution = []

        if Utils.file_exists(folder):
            try:
                process = subprocess.Popen(
                    split('pyre --strict --noninteractive --output text --source-directory \"{}\" check'.format(folder)),
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, encoding='utf8'
                )
                while True:
                    output = process.stdout.readline()
                    if output == '' and process.poll() is not None:
                        break
                    if output:
                        result_execution.append(output.strip())
                        # CustomLogger.instance().logger(output.strip(), not_track=True)
            except KeyboardInterrupt:
                # process.terminate()
                exit()
            except Exception as ex:
                CustomLogger.instance().logger('err: {}'.format(ex))

        return result_execution
