from rope.base.project import Project
from rope.refactor import extract
from custom_logger import CustomLogger
from refactoring_base import BaseRefactoring


class ExtractMethodRefactoring(BaseRefactoring):

    def apply(self):
        CustomLogger.instance().logger(
            message='Rename refactoring: self.file_to_refactor: {} | self.from_position: {} | self.new_method_name: {}'.format(
                self.file_to_refactor, self.from_position, self.new_method_name))
        try:
            project = Project(self.project_folder)
            from_move_file = self.find_module_in_project(project, self.file_to_refactor)
            changes = extract.ExtractMethod(
                project,
                from_move_file,
                self.from_position,
                self.end_position
            )

            project.do(changes.get_changes(self.new_method_name))
        except Exception as err:
            CustomLogger.instance().logger(message='Error during refactoring application. Err: {}'.format(err))
            raise ValueError(err)

    def __init__(self, file_to_refactor, from_position, end_position, project_folder='./'):
        self.file_to_refactor = file_to_refactor
        self.from_position = from_position
        self.project_folder = project_folder
        self.end_position = end_position
        self.new_method_name = 'extracted_method'
