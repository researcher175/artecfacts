import os
import time


class CustomLogger:

    _instance = None

    def __init__(self):
        self.timestamp = '_'.join(time.ctime(time.time()).split(' ')[1:])
        self.base_folder = 'results_{}'.format(self.timestamp)
        self.create_result_folder()
        self.enabled = True

    @classmethod
    def instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def create_result_folder(self):
        os.mkdir(self.base_folder)

    def get_base_folder(self):
        return self.base_folder

    def set_enable(self, flag):
        self.enabled = flag

    def logger(self, message, new_line=False, not_track=False, file=''):
        track = 'TRACK: '

        if not_track:
            track = ''

        if new_line:
            track = '\n{}'.format(track)

        if self.enabled:
            print('{}{}'.format(track, message))

        if file:
            with open('{}/{}.txt'.format(self.base_folder, file), 'a') as file:
                file.write('{}{}\n'.format(track, message))

        with open('{}/log.txt'.format(self.base_folder), 'a') as file:
            file.write('{}{}\n'.format(track, message))

    def add_prefix_to_result_folder(self, name):
        if os.path.exists(self.base_folder):
            os.rename(self.base_folder, 'results_{}_{}'.format(name, self.timestamp))
        else:
            print('The file {} does not exist'.format(self.base_folder))
