import os.path
import random
import json

from ast_utils import AstUtils
from custom_logger import CustomLogger
from git_controller import GitController
from refactoring_inline import InlineMethodRefactoring
from refactoring_use_function import UseFunctionRefactoring
from type_checker import TypeChecker
from utils import Utils
from refactoring_rename import RenameRefactoring
from texttable import Texttable
import re


def get_output_pytype(normalized_path):
    return TypeChecker.run_pytype(normalized_path)


def run_pytype(files, save_base_file=False):
    log = CustomLogger.instance()
    result_pytype = {}

    for to_check_file in files:
        normalized_path = os.path.normpath(os.path.join(os.getcwd(), to_check_file))
        output = get_output_pytype(normalized_path)
        py_file = normalized_path.split('/')[-1]
        result_pytype[py_file] = output

        if save_base_file:
            Utils.append_to_file('{}/result_base_pytype.txt'.format(log.get_base_folder()),
                                 'file: {}'.format(to_check_file))
            Utils.append_to_file('{}/result_base_pytype.txt'.format(log.get_base_folder()), output)

    return result_pytype


def get_output_pyre(folder):
    return TypeChecker.run_pyre(folder)


def run_pyre(files, save_base_file=False):
    log = CustomLogger.instance()
    arr_file = files[0].split('/')
    root_folder = '/'.join([arr_file[0], arr_file[1], arr_file[2], ''])

    log.logger('Start type checkers in {}'.format(root_folder))
    project_root_folder_normalized = os.path.normpath(os.path.join(os.getcwd(), root_folder))
    result = get_output_pyre(project_root_folder_normalized)

    if save_base_file:
        Utils.append_to_file('{}/result_base_pyre.txt'.format(log.get_base_folder()), '\n'.join(result))
    return result


def run_type_checker(files):
    return {
        'pyre': run_pyre(files, save_base_file=True)
    }


def remove_list_intersection(list1, list2):
    result = {}
    clean_log(list1)
    clean_log(list2)

    intersection = set(list1).intersection(set(list2))
    result['list1'] = set(list1) - intersection
    result['list2'] = set(list2) - intersection
    return result


def list_diff(list1, list2):
    clean_log(list1)
    clean_log(list2)

    c = set(list1).union(set(list2))
    d = set(list1).intersection(set(list2))
    return list(c - d)


def clean_log(lines):
    regex = '^[0-9]*-[0-9]*-[0-9]+ [0-9]+:[0-9]+:[0-9]+,[0-9]+ \[[A-Za-z0-9]* [A-Za-z0-9]*\] '
    tags = ['PERFORMANCE', 'INFO Writing arguments into']
    for index in range(len(lines)):
        if re.search(regex, lines[index]):
            lines[index] = re.sub(regex, '', lines[index])

        for tag in tags:
            if re.search(tag, lines[index]):
                lines[index] = ''


def generate_pyre_files_dict(lines):
    files_dict = {}
    regex = '[A-Za-z0-9]+\.py:[0-9]+:[0-9]+ [A-Za-z0-9 ]+\[[0-9]+\]'
    for index in range(len(lines)):
        if re.search(regex, lines[index]):
            extracted = re.findall(regex, lines[index])
            file_name = extracted[0].split(' ')[0].split(':')[0]
            warning = ' '.join(extracted[0].split(' ')[1:])

            if file_name in files_dict:
                files_dict[file_name].append(warning) if warning not in files_dict[file_name] else files_dict[file_name]
            else:
                files_dict[file_name] = [warning]

    return files_dict

def remove_path_details(lines):
    regex = '[A-Za-z0-9_]+\.py:[0-9]+:[0-9]+ [A-Za-z0-9 ]+\[[0-9]+\]'
    for index in range(len(lines)):
        line = lines[index]

        if re.search(regex, line):
            extracted = re.findall(regex, line)
            file_name = extracted[0].split(' ')[0].split(':')[0]
            type_error = ' '.join(extracted[0].split(' ')[1:])
            lines[index] = '{}'.format(type_error)

    return lines


def categorize_lines_messages(lines):
    global messages_per_type_error

    logger.logger(message='lines:\n {}'.format(json.dumps(lines, indent=1)),
                  new_line=True, not_track=True, file='messages_per_error')

    regex = '[A-Za-z0-9_]+\.py:[0-9]+:[0-9]+ [A-Za-z0-9 ]+\[[0-9]+\]'
    regex_variations = '`([^`]+)`'
    for index in range(len(lines)):
        line = lines[index]

        if re.search(regex, line):
            extracted = re.findall(regex, line)
            type_error = ' '.join(extracted[0].split(' ')[1:])
            type_error_message = line[line.find(']:')+2:].strip()
            type_error_message_without_variations = re.sub(regex_variations, '_', type_error_message)

            if type_error in messages_per_type_error.keys():
                messages_per_type_error[type_error].append(type_error_message_without_variations)
                messages_per_type_error[type_error] = list(set(messages_per_type_error[type_error]))
            else:
                messages_per_type_error[type_error] = [type_error_message_without_variations]



def format_list_string(list_errors, filter=False):
    global total_type_errors

    line_error_regex = r'^ERROR'
    line_info_regex = r'^INFO'
    line_memory_regex = r'^MEMORY'

    line = ''
    for item in list_errors:
        if not filter:
            line += item + '\n'
            total_type_errors += 1
        else:
            line += (item + '\n') if not (re.search(line_error_regex, item) or re.search(line_info_regex, item) or re.search(line_memory_regex, item)) else ''

    return line


def extract_numbers_from_lines(lines):
    pattern = r'\b\d+\b'

    numbers = []

    for line in lines:
        matches = re.findall(pattern, line)

        if matches:
            numbers.extend([int(match) for match in matches])

    return numbers


def is_correct(list_new, list_base):
    if len(list_new) == 0 or len(list_base) == 0:
        return False

    line_error_regex = r'^ERROR'
    line_info_regex = r'^INFO'
    numbers = [0, 0]
    numbers_base = [0, 0]
    has_lines = [False, False, False, False]

    if len(list_new) <= 2:
        for line in list_new:
            has_one = False
            if re.search(line_info_regex, line):
                has_one = True
                has_lines[1] = True
                numbers[1] = extract_numbers_from_lines([line])[0]

            if re.search(line_error_regex, line):
                has_one = True
                has_lines[0] = True
                numbers[0] = extract_numbers_from_lines([line])[0]

            print('is_correct.has_one.list_new: {}\nis_correct.has_lines.list_new: [error].{} [info].{}\nis_correct.numbers.list_new: [error].{} [info].{}'.format(has_one, has_lines[0], has_lines[1], numbers[0], numbers[1]))
            if not has_one:
                return has_one

        for line in list_base:
            has_one = False
            if re.search(line_info_regex, line):
                has_one = True
                has_lines[3] = True
                numbers_base[1] = extract_numbers_from_lines([line])[0]

            if re.search(line_error_regex, line):
                has_one = True
                has_lines[2] = True
                numbers_base[0] = extract_numbers_from_lines([line])[0]

            print('is_correct.has_one.list_base: {}\nis_correct.has_lines.list_base: [error].{} [info].{}\nis_correct.numbers.list_base: [error].{} [info].{}'.format(has_one, has_lines[2], has_lines[3], numbers_base[0], numbers_base[1]))
            if not has_one:
                return has_one

        print('{} and {}: {} < {}'.format(has_lines[0], has_lines[2], numbers[0], numbers_base[0]))
        print('{} and {}: {} < {}'.format(has_lines[1], has_lines[3], numbers[1], numbers_base[1]))
        if has_lines[0] and has_lines[2]:
            return numbers[0] < numbers_base[0]

        if has_lines[1] and has_lines[3]:
            return numbers[1] < numbers_base[1]

    return False


def is_false_positive(list_new):
    if len(list_new) == 0:
        return True

    line_error_regex = r'^ERROR'
    line_info_regex = r'^INFO'
    has_lines = [False, False]

    if len(list_new) <= 2:

        for line in list_new:
            if re.search(line_info_regex, line):
                has_lines[1] = True

            if re.search(line_error_regex, line):
                has_lines[0] = True

        if ((len(list_new) == 1 and (has_lines[0] or has_lines[1]))
                or (len(list_new) == 2 and has_lines[0] and has_lines[1])):
            return True

    return False


def has_static_difference(root_folder, analyse_file, field, result_base, git_controller):
    global categories

    py_file = '/'.join(analyse_file.split('/')[-2:])
    rows = [['tool', 'new output diff', 'old base output']]
    result = fp = correct_transformation = False
    new_type_errors = ''

    # pyre
    output_pyre = get_output_pyre(os.path.join(os.getcwd(), root_folder))
    diff_from_base = list_diff(output_pyre, result_base['pyre'])
    if len(diff_from_base) > 0:
        logger.logger('list1: {}'.format(output_pyre), new_line=True)
        logger.logger('list2: {}'.format(result_base['pyre']), new_line=True)

        logger.logger('diff in pyre: file: {}\nfield: {}\n{}'.format(py_file, field, diff_from_base), new_line=True)

        cleaned_list = remove_path_details(diff_from_base)
        without_duplicate_list = list(set(cleaned_list))
        if len(without_duplicate_list) > 1:
            lists_without_intersection = remove_list_intersection(output_pyre, result_base['pyre'])
            list1 = remove_path_details(lines=list(lists_without_intersection['list1']))  # introduced type errors
            list2 = remove_path_details(list(lists_without_intersection['list2']))
            diff_lists = remove_list_intersection(list1, list2)

            categorize_lines_messages(list(lists_without_intersection['list1']))

            fp = is_false_positive(diff_lists['list1'])
            correct_transformation = is_correct(diff_lists['list1'], diff_lists['list2'])
            result = True

            rows.append(['pyre\nfile: {}\nfield: {}\nis_fp: {}\nis_correct: {}'.format(py_file, field, fp, correct_transformation),
                         '{}'.format(format_list_string(diff_lists['list1'])),
                         '{}'.format(format_list_string(diff_lists['list2']))
                         ]
                        )
            new_type_errors = format_list_string(list_errors=diff_lists['list1'], filter=True)
            if new_type_errors in categories.keys():
                categories[new_type_errors] += 1
            else:
                categories[new_type_errors] = 1

    if result:
        diff = '-'*50 + '\n\n\n' + git_controller.get_diff() + '\n\n\n'
        table = Texttable()
        table.set_max_width(0)
        table.add_rows(rows=rows)
        draw_table = table.draw()
        logger.logger(message='\n' + draw_table, new_line=True)
        logger.logger(message='New errors: {}'.format(new_type_errors), new_line=True)
        logger.logger(message='Categories: {}'.format(categories), new_line=True)

        if correct_transformation:
            Utils.append_to_file('{}/diffs_correct_transformation.txt'.format(logger.get_base_folder()), diff + repr(new_type_errors) + '\n\n' + draw_table + '\n\n')
        elif fp:
            Utils.append_to_file('{}/diffs_fp.txt'.format(logger.get_base_folder()), diff + repr(new_type_errors) + '\n\n' + draw_table + '\n\n')
        else:
            Utils.append_to_file('{}/diffs.txt'.format(logger.get_base_folder()), diff + repr(new_type_errors) + '\n\n' + draw_table + '\n\n')

        Utils.write_file(
            './{}/report_{}_{}.txt'.format(logger.get_base_folder(), py_file.replace('/', '_'), field),
            '\n'.join(output_pyre)
        )

    return result, fp, correct_transformation


def apply_refactoring(root, file, to_refact, refact_targets, git_controller, result_base):
    global refactor_type

    refac_errors = static_diff = fp = correct = 0

    for target in list(refact_targets.keys()):
        logger.logger('\n----------------- START TARGET [ {} ] [ {} ] -----------------\n'.format(target, file))
        position = refact_targets[target]
        refactoring = get_refactoring_instance(file, to_refact, position, '{}_refactored'.format(target), root)
        logger.logger('Applying refactoring to {} in {} at position {}'.format(file, target, position))

        try:
            refactoring.apply()
        except ValueError as err:
            add_keyword_failure()
            Utils.append_to_file(
                '{}/diffs.txt'.format(logger.get_base_folder()),
                'Cannot apply:\nAppyling refactoring to {} in {} at position {}\nFile: {}\nError:{}\n\n'.format(file, target, position, to_refact, err, refactoring.to_rename)
            )
            refac_errors += 1
            logger.logger('Cannot apply, file: {}'.format(file), new_line=True)

            return_to_default_branch(git_controller, checkout=True)
            logger.logger('\n----------------- END TARGET [ {} ] [ {} ]  -----------------\n'.format(target, file))
            continue

        has_static_diff = has_static_difference(root, os.path.normpath(os.path.join(os.getcwd(), file)), target, result_base, git_controller)
        if has_static_diff[0]:
            logger.logger('Has difference, file: {}'.format(file), new_line=True)
            add_keyword_failure()

            diff_type = 'diff'

            if has_static_diff[2]:
                diff_type = 'correct'
                correct += 1
            elif has_static_diff[1]:
                diff_type = 'false_positive'
                fp += 1
            else:
                static_diff += 1

            push_diff(git_controller=git_controller,
                      branch='{}_{}_{}_{}'.format(refactor_type, target, diff_type, position),
                      commit='Has difference: {} in {} at position {}'.format(file, target, position)
                      )

        else:
            logger.logger('Has no difference, file: {}'.format(file), new_line=True)

        return_to_default_branch(git_controller, checkout=True)
        logger.logger('\n----------------- END TARGET [ {} ] [ {} ]  -----------------\n'.format(target, file))

    return refac_errors, static_diff, fp, correct


def push_diff(git_controller, branch, commit):
    git_controller.create_and_checkout_to_branch(branch)
    git_controller.commit_and_push_to_remote(commit)


def return_to_default_branch(git_controller, checkout=False):
    if checkout:
        git_controller.checkout_all()

    git_controller.checkout_to_branch('master')


def get_value_to_rename(considered_file):
    # >> > import keyword
    # >> > keyword.kwlist
    # words = ['False', 'None', 'True', 'and', 'as', 'assert', 'async', 'await', 'break', 'class',
    #          'continue', 'def', 'del', 'elif', 'else', 'except', 'finally', 'for', 'from', 'global',
    #          'if', 'import', 'in', 'is', 'lambda', 'nonlocal', 'not', 'or', 'pass', 'raise', 'return',
    #          'try', 'while', 'with', 'yield']

    global refactor_type
    global refactorings
    global key_word
    reserved_keywords = [
        'False', 'class', 'from', 'or', 'None', 'continue', 'global', 'pass', 'True', 'def', 'if',
        'raise', 'and', 'del', 'import', 'return', 'as', 'elif', 'in', 'try', 'assert', 'else', 'is',
        'while', 'async', 'except', 'lambda', 'with', 'await', 'finally', 'nonlocal', 'yield', 'break', 'for', 'not'
    ]

    match refactorings.index(refactor_type):
        case 1:
            variables_names = AstUtils.get_variables(considered_file)

            if len(variables_names) > 0:
                list_variables = list(variables_names.keys())
                index = 0 if len(list_variables) == 1 else random.randrange(0, len(list_variables))
                return list_variables[index]
            else:
                return ''
        case 0:
            methods_names = AstUtils.get_methods(considered_file, False)

            if len(methods_names) > 0:
                list_methods = list(methods_names.keys())
                index = 0 if len(list_methods) == 1 else random.randrange(0, len(list_methods))
                return list_methods[index]
            else:
                return ''
        case 2:
            key_word = reserved_keywords[random.randrange(0, len(reserved_keywords)-1)]
            return key_word
        case 3:
            key_word = reserved_keywords[random.randrange(0, len(reserved_keywords)-1)]
            return key_word
        case _:
            return ''


def get_itens_to_refac(file_to_analyze):
    global refactor_type
    global refactorings

    match refactorings.index(refactor_type):
        case 0: # rename field
            return AstUtils.get_variables(file_to_analyze)
        case 1: # rename method
            return AstUtils.get_methods(file_to_analyze, False)
        case 2: # rename field with reserved keywords
            return AstUtils.get_variables(file_to_analyze)
        case 3: # rename method with reserved keywords
            return AstUtils.get_methods(file_to_analyze, False)
        case 4: # use function refactoring
            return AstUtils.get_methods(file_to_analyze, True)
        case 5: # inline method
            return AstUtils.get_methods(file_to_analyze, False)
        case _:
            return AstUtils.get_variables(file_to_analyze)


def get_refactoring_instance(root_file, file_to_refact, position, to_rename, project_folder):
    global refactor_type
    global refactorings

    value_to_rename = get_value_to_rename(root_file)

    if value_to_rename == '':
        value_to_rename = to_rename

    match refactorings.index(refactor_type):
        case 0: # rename field
            return RenameRefactoring(file_to_refact, position, value_to_rename, project_folder)
        case 1: # rename method
            return RenameRefactoring(file_to_refact, position, value_to_rename, project_folder)
        case 2: # rename field with reserved keywords
            return RenameRefactoring(file_to_refact, position, value_to_rename, project_folder)
        case 3: # rename method with reserved keywords
            return RenameRefactoring(file_to_refact, position, value_to_rename, project_folder)
        case 4:
            return UseFunctionRefactoring(file_to_refact, position, project_folder)
        case 5:
            return InlineMethodRefactoring(file_to_refact, position, project_folder)
        case _:
            return RenameRefactoring(file_to_refact, position, to_rename, project_folder)


def add_keyword_failure():
    global keywords_with_new_type_errors, key_word

    if key_word != '':
        if key_word in keywords_with_new_type_errors.keys():
            keywords_with_new_type_errors[key_word] += 1
        else:
            keywords_with_new_type_errors[key_word] = 1


def main():
    py_files = Utils.file_selector(PROJECTS_FOLDER)
    result_base = run_type_checker(py_files)
    len_variables = without_vars = refactoring_apply_err = issues = fps = corrects = 0

    for file in py_files:
        logger.logger(message='Interact: {}'.format(file), new_line=True)

        file_arr = file.split('/')
        root = '/'.join([file_arr[0], file_arr[1], file_arr[2], ''])
        for i in range(3):
            del file_arr[0]
        module = '.'.join(file_arr).replace('.py', '')

        variables = get_itens_to_refac(file)

        if len(variables.keys()) <= 0:
            without_vars += 1
            continue

        len_variables += len(variables.keys())

        git_controller = GitController(root)
        to_refact = '{}.py'.format(module.replace('.', '/'))
        results = apply_refactoring(root, file, to_refact, variables, git_controller, result_base)
        refactoring_apply_err += results[0]
        issues += results[1]
        fps += results[2]
        corrects += results[3]

    logger.logger(message='Total files: {}\n{}'.format(len(py_files), py_files, new_line=True))

    final_table = Texttable()
    final_table.set_max_width(0)

    final_table.add_rows([
        ['Project', 'Modules', 'Without variables', 'Variables (targets)', 'No diff', 'Cannot apply', 'Issues', 'False Positive (FP)', 'Correct application (CA)', 'Cannot apply + Issues + FP + CA'],
        [py_files[0].split('/')[2], len(py_files), without_vars, len_variables, (len_variables - refactoring_apply_err - fps - corrects - issues), refactoring_apply_err, issues, fps, corrects, (refactoring_apply_err + fps + corrects + issues)]
    ])

    logger.logger(message=final_table.draw(), new_line=True, not_track=True)
    logger.logger(message='Categories:\n {}'.format(json.dumps(categories, indent=1)), new_line=True, not_track=True, file='categories')
    logger.logger(message='Keywords with new type errors frequency:\n {}'.format(json.dumps(keywords_with_new_type_errors, indent=1)), new_line=True, not_track=True, file='keywords_frequency')
    logger.logger(message='Message per type error:\n {}'.format(json.dumps(messages_per_type_error, indent=1)), new_line=True, not_track=True, file='messages_per_error')
    logger.logger(message='Total type errors:\n {}'.format(total_type_errors), new_line=True, not_track=True)
    logger.add_prefix_to_result_folder('{}_{}'.format(refactor_type, py_files[0].split('/')[2]))


logger = CustomLogger.instance()
PROJECTS_FOLDER = './project/'
refactorings = [
    'RenameField', 'RenameMethod', 'RenameField_reservedKeywords', 'RenameMethod_reservedKeywords',
    'UseFunction', 'Inline'
]
refactor_type = refactorings[5]

total_type_errors = 0
categories = {}
keywords_with_new_type_errors = {}
key_word = ''
messages_per_type_error = {}

main()

